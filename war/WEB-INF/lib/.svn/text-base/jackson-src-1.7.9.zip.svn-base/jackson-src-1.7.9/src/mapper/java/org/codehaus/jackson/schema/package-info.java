/**
 * Classes needed for JSON schema support (currently just ability
 * to generate schemas using serialization part of data mapping)
 */
package org.codehaus.jackson.schema;
